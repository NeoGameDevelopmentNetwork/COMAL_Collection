
Short:        Comal v3.40
Author:       Svend@DaugaardPedersen.dk (Svend Daugaard Pedersen)
Uploader:     Svend DaugaardPedersen dk (Svend Daugaard Pedersen)
Type:         dev/lang
Architecture: m68k-amigaos

Comal version 3.40 (1996.01.11)

Comal is a BASIC dialect with a lot of language constructs
from more modern languages like Pascal, C and C++.

This version of Comal contains in addition to Comal80:

 - types (float, integer, byte and long)
 - structures with methods (classes)
 - class constructures and destructures
 - class inheritance
 - virtual methods
 - modules
 - low level facilities like pointers and direct call of C/asm code

The programming environment includes a screen editor with syntax
controll and a debugger (single stepping, break points etc.).

A set of modules with prefix CIT enable you to create intuition
objects in an easy way and to make interrupt driven programs.
This CIT system is a predessor for the CIT system I have used
in BetaScan.

I have stopped devellopment. The doc file is not in Amiga Guide
format :-( and may be not 100% up to date ;-)

There is no install script. Just copy the the Comal drawer to a place
you like. If you choose Work: you don't have to change the default
tool in the icons.